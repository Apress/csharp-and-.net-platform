Greetings!

I hope you enjoy reading C# and the .NET Platform.
Here is the sample code that works with the chapters
of the text.  Before you load things up, a few points:

-> Chapter 14 does not have any sample code (this
is not an ommission).  Most of these examples are
recreated simply using the IDE.

-> I have deleted all /bin folders to shrink the size
of the code download.  Therefore, all projects must
be recompiled.

-> When you are building applications which 
reference external custom assemblies, you will
need to reset the reference using VS .NET.

-> For the COM interop samples, be sure you
compile and register the COM servers before
running the clients!

Beyond these unavoidable configuration tasks, using 
and extending the sample code should be a no-brainer.

So, enjoy the universe of .NET and take care.

Andrew Troelsen
www.intertech-inc.com

