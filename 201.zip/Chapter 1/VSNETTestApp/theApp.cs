namespace VSNETTestApp
{
    using System;
	using System.Windows.Forms;


    /// <summary>
    ///    Summary description for Class1.
    /// </summary>
    public class AppClass
    {
        public AppClass()
        {
            //
            // TODO: Add Constructor Logic here
            //
        }

        public static int Main(string[] args)
        {
            Console.WriteLine("Hello again!");
			MessageBox.Show("Hey...");
            return 0;
        }
    }
}
