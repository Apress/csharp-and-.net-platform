namespace Chapter2Types
{
namespace MyShapes
{
using System;

	// Circle class.
	class Circle
	{
		public Circle()
		{
			Console.WriteLine("Making a Circle!");
		}
	}

	// Hexagon class
	class Hexagon
	{
		public Hexagon()
		{
			Console.WriteLine("Making a Hexagon!");
		}

	}

	// Square class
	class Square
	{
		public Square()
		{
			Console.WriteLine("Making a Square!");
		}
	}

}
}